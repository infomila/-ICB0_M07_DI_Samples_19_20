﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Control de usuario está documentada en https://go.microsoft.com/fwlink/?LinkId=234236

namespace Botiga.View
{
    public sealed partial class AmorDeDAM : UserControl
    {
        public AmorDeDAM()
        {
            this.InitializeComponent();
        }



        public int Rate
        {
            get { return (int)GetValue(RateProperty); }
            set { SetValue(RateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Rate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RateProperty =
            DependencyProperty.Register("Rate", typeof(int), typeof(AmorDeDAM), 
                new PropertyMetadata(0, OnRateChangedCallback));

        private static void OnRateChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            AmorDeDAM a = (AmorDeDAM)d;
            a.OnRateChangedCallbackNormal();
        }

        private void OnRateChangedCallbackNormal()
        {
            String t = "";
            for(int i=0;i<5;i++)
            {
                if(i<Rate)
                {
                    t+="\xEB52";
                } else {
                    t += "\xEB51";
                }
            }
            tbkCors.Text = t;
        }
    }
}
