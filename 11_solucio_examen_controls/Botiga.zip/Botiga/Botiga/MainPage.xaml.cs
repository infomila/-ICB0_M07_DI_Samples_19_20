﻿using Botiga.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace Botiga
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            cboCat.ItemsSource = Category.GetAllCategories();
            lsvProducts.ItemsSource = Product.GetAllProducts();
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            ObservableCollection<Product> theFilteredProducts = new ObservableCollection<Product>();
            foreach( Product p in Product.GetAllProducts())
            {
                if ( ( cboCat.SelectedItem!=null && cboCat.SelectedItem == p.TheCategory)
                    &&
                    (txbNameFilter.Text.Length==0 || p.Name.IndexOf(txbNameFilter.Text)>=0)
                    ) {
                    theFilteredProducts.Add(p);
                }
            }
            lsvProducts.ItemsSource = theFilteredProducts;
        }
    }
}
