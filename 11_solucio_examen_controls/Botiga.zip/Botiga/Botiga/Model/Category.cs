﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Botiga.Model
{
    public class Category
    {

        private static ObservableCollection<Category> theCategories;
        // Dani sponsored change:
        public static ObservableCollection<Category> GetAllCategories()
        {
            if(theCategories==null)
            {
                theCategories = new ObservableCollection<Category>();
                theCategories.Add(new Category("ms-appx:///Assets/cat_audio.png", "Audio"));
                theCategories.Add(new Category("ms-appx:///Assets/cat_mobile.png", "Mobile"));
                theCategories.Add(new Category("ms-appx:///Assets/cat_photo.png", "Photo"));
                theCategories.Add(new Category("ms-appx:///Assets/cat_tv.png", "TV"));
            }
            return theCategories;
        }


        string imgUrl;
        string name;

        public Category(string imgUrl, string name)
        {
            this.ImgUrl = imgUrl;
            this.Name = name;
        }

        public string ImgUrl { get => imgUrl; set => imgUrl = value; }
        public string Name { get => name; set => name = value; }
    }
}
