﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Botiga.Model
{
    public class Product
    {
        string description;
        string name;
        decimal price;
        int rating;
        Category theCategory;

        private static ObservableCollection<Product> theProducts;
        // Dani sponsored change:
        public static ObservableCollection<Product> GetAllProducts()
        {
            if (theProducts == null)
            {
                theProducts = new ObservableCollection<Product>();
                theProducts.Add(new Product("el fantastico mòbil", "Huawei 564", 342.3m, 3, Category.GetAllCategories()[1]) );
                theProducts.Add(new Product("el fantastico mòbil 2", "Nexus Pixel 4", 800.4m, 5, Category.GetAllCategories()[1]));
                theProducts.Add(new Product("el fantastico mòbil 2", "IPod", 200m, 2, Category.GetAllCategories()[0]));
            }
            return theProducts;
        }





        public Product(string description, string name, decimal price, int rating, Category theCategory)
        {
            this.Description = description;
            this.Name = name;
            this.Price = price;
            this.Rating = rating;
            this.TheCategory = theCategory;
        }

        public string Description { get => description; set => description = value; }
        public string Name { get => name; set => name = value; }
        public decimal Price { get => price; set => price = value; }
        public int Rating { get => rating; set => rating = value; }
        public Category TheCategory { get => theCategory; set => theCategory = value; }
    }
}
